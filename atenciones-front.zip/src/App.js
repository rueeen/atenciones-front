import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";

import LoginForm from "./components/LoginForm";
import AtencionList from "./components/AtencionList";
import AtencionForm from "./components/AtencionForm";
import Perfil from "./components/Perfil";
import CrearUsuarioForm from "./components/CrearUsuarioForm";

import PrivateRoute from "./components/PrivateRoute";
import AdminRoute from "./components/AdminRoute";

function App() {
  return (
    <Router>
      <div className="container mt-4">
        <Routes>
          {/* Ruta pública */}
          <Route path="/login" element={<LoginForm />} />

          {/* Rutas protegidas para usuarios autenticados */}
          <Route
            path="/atenciones"
            element={
              <PrivateRoute>
                <AtencionList />
              </PrivateRoute>
            }
          />
          <Route
            path="/nueva-atencion"
            element={
              <PrivateRoute>
                <AtencionForm />
              </PrivateRoute>
            }
          />
          <Route
            path="/perfil"
            element={
              <PrivateRoute>
                <Perfil />
              </PrivateRoute>
            }
          />

          {/* Ruta protegida solo para superadmin */}
          <Route
            path="/usuarios/nuevo"
            element={
              <AdminRoute>
                <CrearUsuarioForm />
              </AdminRoute>
            }
          />

          {/* Redirección por defecto */}
          <Route path="*" element={<Navigate to="/atenciones" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
